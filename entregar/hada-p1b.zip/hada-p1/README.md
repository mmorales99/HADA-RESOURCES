# hada-p1
Repositorio de la asignatura de HADA/EADA de la practica 1

P1:
se ha subido la rama master, unicamente

P2:
Muestra en dos slides diferentes los cambios realizados entre la version guardada en el repositorio y la version que se esta modificando

P3:
No, ha detectado divergencias en los archivos remotos y locales, pide hacer un git pull, un git push o subir a una rama diferente

P4:
Confirmar todo guarda todos los cambios hechos en el local y hace un commit con todos los cambios
Commit all : git add * && git commit --allow-empty-message -m ""

P5:
Confirmar todo e insertar guarda todos los cambios y los guarda
Confirm all and push: git add * && git commit --allow-empty-message -m "" && git push -u origin <branch>
  
P6:
Confirmar todo y sincronizar guarda todos los cambios y prueba a hacer un push, si el resultado es fallido, hace un pull y después un push
el comando equivalente encuanto a funcionalidad es: git add * && git stash && git fetch && git add * && git commit --allow-empty-message -m "" && git push -u origin <branch>
  
P7:
Sincronizar: git fetch
Extraer: git pull || git fetch && git merge FETCH_HEAD
Sincronizar descarga los archivos faltantes en la copia local
Extraer hace lo mismo que sincronizar si no se ha sincronizado y mezcla los cambios del repositorio local con el remoto y hace un commit
