# EADA - Practica 1a : Uso de git  
  
## P1:  
La opcion -n o --no-commit hace que al ejecutar 'git reverse -n HEAD' no se haga commit en cada archivo recuperado de la version anterior  
  
## P2:  
'git reset --hard' borra todos los cambios hechos a un commit, si borramos este archivo podemos usar esta opcion para volver a tenerlo en nuestro sistema antes de hacer ning�n commit  
  
## P3:  
La diferencia basica entre revert y reset es que revert permite devolver el estado de todo el proyecto a un estado guardado en concreto; reset borra todos los cambios hechos, guardados en el workingtree y en el indice para dejar el proyecto en igualdad de condiciones al ultimo commit hecho  
  
## P4:  
