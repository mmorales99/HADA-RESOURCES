﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hada_p1
{
    ///<summary>
    ///Clase que contiene la funciones que estamos creando
    ///</summary>
    class HadaP1
    {
        ///<summary> Función que recive segundos y los devuelve convertidos en minutos</summary>
        ///<param name="s">segundos a convertir, representado en doble</param>
        ///<return>segundos convertidos en minutos, representado en doble</return>
        public static double Seconds2Minutes(double s) {
            return ( s == 0 ? 0 : ( s / 60.0 ) );
        }

        ///<summary> Función que recive minutos y los devuelve convertidos en segundos</summary>
        ///<param name="m">minutos a convertir, representado en doble</param>
        ///<return>minutos convertidos en minutos, representado en doble</return>
        public static double Minutes2Seconds(double m)
        {
            return ( m == 0 ? 0 : ( m * 60.0 ) );
        }
        
        ///<summary> Función que recive horas y las devuelve convertidas en minutos</summary>
        ///<param name="h">horas a convertir, representado en doble</param>
        ///<return>horas convertidas en minutos, representado en doble</return>
        public static double Hours2Minutes(double h)
        {
            return ( h == 0 ? 0 : ( h * 60.0 ) );
        }
    }
}
