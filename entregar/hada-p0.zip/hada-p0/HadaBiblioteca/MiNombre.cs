﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HadaBiblioteca
{
    public class MiNombre
    {
        public string Nombre { get; }
        public MiNombre(string nombre) {
            Nombre = nombre;
        }
        public void Write() {
            System.Console.WriteLine("My name is {0}",Nombre);
        }

    }
}
